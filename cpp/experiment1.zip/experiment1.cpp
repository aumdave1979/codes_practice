#include <iostream>
#include <string>
using namespace std;

class Employee {
private:
   int salary;

public:
   string name;
   string EMP_ID;
   string gender;

   void setData(int s);

   void getData() {
      cout << "Name : " << name << endl;
      cout << "Emp_ID: " << EMP_ID << endl;
      cout << "Gender: " << gender << endl;
      cout << "Salary: " << salary << endl;
   }

   void updateSalary(int x) {
      salary = salary + x;
   }
};

void Employee::setData(int s) {
   salary = s;
}

int main() {
   const int n = 10;
   Employee emp[n];

   cout << "Aum Dave" << endl;
   cout << "92400133058" << endl;

   for(int i = 0; i < n; i++) {
      cout << "Enter the details of number " << i + 1 << " Employee : " << endl;

      cout << "Enter your name : ";
      cin >> emp[i].name;

      cout << "Enter your empid : ";
      cin >> emp[i].EMP_ID;

      cout << "Enter your gender : ";
      cin >> emp[i].gender;

      int sal;
      cout << "Enter your salary : ";
      cin >> sal;
      emp[i].setData(sal);
   }

   return 0;
}
